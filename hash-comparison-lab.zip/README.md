# Hash Comparison Lab – Cybersecurity Activity

## Overview
This project demonstrates how to detect file tampering using SHA-256 hash comparison. 
Even visually identical files can produce different hashes if there's a hidden character like a space.

## Scenario
- You have two files: `file1.txt` and `file2.txt`.
- Both appear identical using `cat`, but `sha256sum` shows different hashes.
- You write the hashes to separate files and compare them using `cmp`.

## Commands Used
```bash
ls
cat file1.txt
cat file2.txt
sha256sum file1.txt
sha256sum file2.txt
sha256sum file1.txt >> file1hash
sha256sum file2.txt >> file2hash
cat file1hash
cat file2hash
cmp file1hash file2hash
```

## Expected Output
```bash
sha256sum file1.txt
131f95c51cc819465fa1797f6ccacf9d494aaaff46fa3eac73ae63ffbdfd8267  file1.txt

sha256sum file2.txt
2558ba9a4cad1e69804ce03aa2a029526179a91a5e38cb723320e83af9ca017b  file2.txt

cmp file1hash file2hash
file1hash file2hash differ: char 1, line 1
```

## Conclusion
This lab shows how even a hidden character can change a file's hash. 
Hashing is a critical skill for validating file integrity in cybersecurity.
